<footer class="footer text-right">
	2018 © StudyLinkAdmin. - By My Students!
</footer>